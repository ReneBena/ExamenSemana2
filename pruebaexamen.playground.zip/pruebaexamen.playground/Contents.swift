//: Playground - noun: a place where people can play

import UIKit


var numeros = 0...100

//  generar una serie de numero de 0 al 100 incluido el 100

print(numeros)

//  si el numero es divisible entre 5 debe de imprimir numero y la palabra Bingo

for var numero = 0; numero <= numeros.count; numero++ {
    if numero % 5 == 0 {
        print("\(numero) Bingo")
    }
}

//  Si el numero es par debe de imprimir el numero y la palabra par

for numero in numeros {
    
    if numero % 2 == 0 {
        print("\(numero) Par")
    }
}

//  Si el numero es impar debe de imprmir el numero y la palabra par

for numero in numeros {
    
    if numero % 2 != 0 {
        print("\(numero) Impar")
    }
}

//  Si el numero se encuentra entre 30 a 40 imprimir el numero y la palabra swift

for numero in numeros {
    
    if numero >= 30 && numero <= 40 {
        print("\(numero) Viva Swift")
    }
}

